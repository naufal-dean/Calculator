#include "negativeSqrtException.h"

NegativeSqrtException::NegativeSqrtException() : BaseException("Negative Sqrt") {}

