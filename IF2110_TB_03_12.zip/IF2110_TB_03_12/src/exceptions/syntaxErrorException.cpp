#include "syntaxErrorException.h"

SyntaxErrorException::SyntaxErrorException() : BaseException("Syntax error") {}
