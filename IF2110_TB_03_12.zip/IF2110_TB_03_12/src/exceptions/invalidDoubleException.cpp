#include "invalidDoubleException.h"

InvalidDoubleException::InvalidDoubleException() : BaseException("Invalid double") {}
