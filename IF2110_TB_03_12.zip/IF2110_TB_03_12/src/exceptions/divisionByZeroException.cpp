#include "divisionByZeroException.h"

DivisionByZeroException::DivisionByZeroException() : BaseException("Division by Zero") {}

