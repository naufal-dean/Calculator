var indexSectionsWithContent =
{
  0: "abcdegimnopstuxy~",
  1: "abcdeimnopstu",
  2: "abcdeimnopstu",
  3: "abcdegimnopstu~",
  4: "txy",
  5: "bcu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros"
};

