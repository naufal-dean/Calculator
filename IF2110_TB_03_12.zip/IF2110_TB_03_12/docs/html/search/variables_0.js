var searchData=
[
  ['type_260',['type',['../class_op_button.html#ab7ada1ab0b6e4c1b8be6e7b0d39fc933',1,'OpButton']]]
];
